#include<iostream>
using namespace std;
int main()
{
   int arr[] = {2,3,4,6,7,2,1,5,6,8,1,2};
   int limit = sizeof(arr) / sizeof(arr[0]);
   int arr2[limit];


  for(int i=0;i<limit;i++)
    {
      arr2[i] = 0;
    }



   for(int i=0; i<limit; i++)
   {
      if(arr2[i]==1)
        {
         continue;
        }

        
      int count = 1;


      for(int j = i+1; j<limit; j++)

        {
         if (arr[i] == arr[j])
         {
            arr2[j] = 1;

            count++;
         }
        }
      cout<<" "<<arr[i]<<" occurs  " << count << endl;
   }
    
}
