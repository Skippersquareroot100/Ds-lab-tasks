#include<iostream>
using namespace std;
int main()
{
    int arr[6],arr2[6];
 
    cout<<"Input the elements : \n";

    for(int i=0; i<6; i++)
    {
        cin>>arr[i];
    }
    for(int i=0; i<6; i++)
    {
        arr2[i]=arr[i];
    }
    cout<<"The array is : \n";



    for(int i=0; i<6; i++)
    {
        if((arr2[i]%2==0)&& arr2[i]!=2)
            cout<<arr2[i]<<" ";
    }

  
}


