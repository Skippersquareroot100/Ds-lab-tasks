#include<iostream>
using namespace std;
int main()
{
    int arr[5]={3,7,4,6,8};
    int lg=arr[0];
    int sl=arr[0];
    int sum=0;
    for(int i=4;i>=0;i--)
    {
        cout<<arr[i]<<"\n";
       
        

    }

    for(int i=0;i<5;i++)
    {
         if(arr[i]>lg)
        {
            lg=arr[i];
        }
        
        
        if(sl<arr[0])
        {
            sl=arr[i];
        }
        sum=sum+arr[i];

    }

    cout<<"largest "<<lg<<"\n";
    cout<<"Smallest "<<sl<<"\n";
    cout<<"Sum "<<sum;


}