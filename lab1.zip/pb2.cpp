#include<iostream>
using namespace std;
int main()
{
    int arr[5];
    int Ecount=0;
    int Ocount=0;
    int sum=0;
     cout<<"Insert Value here>>";
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }
    cout<<"the values of array\n";
    for(int i=0;i<5;i++)
    {
        cout<<arr[i]<<"\n";
        if(arr[i]%2==0)
        {
           Ecount++;
           sum=sum+arr[i];
        }
        else
        {
            Ocount++;

        }
    }

    cout<<"The total even numbers-"<<Ecount;

     cout<<"\nThe total odd numbers-"<<Ocount;
     cout<<"\n the sum"<<sum;
     cout<<"\n the Avg"<<sum/5;

       

}