#include<iostream>
using namespace std;

int func(int fac)
{
   int fact=1,count=0;

   for(int i=1;i<=fac;i++)
   {
      if(fac%i==0)
      {
        count++;
      }
     
   }

   if(count==2)
   {
     for(int i=1;i<=fac;i++)
     {
        fact=fact*i;
     }
        
   }
   else
   {
     cout<<"Erorr! not a prime number";
   }

   return fac=fact;

}

int main()
{
      int a;
      cout<<"Please Enter your value here>> ";
      cin>>a;

     

     cout<<"YOUR RESULT IS \n"<<func(a);
}