#include<iostream>
using namespace std;
int func(int a,int b)
{
    for(int i=a;i<b;i++)
   {
    if(i%2==0)
    {
        cout<<i<<" "<<" ";
    }
   }
    cout<<"\nOdd\n";
   for(int i=a;i<b;i++)
   {
    if(i%2==0)
    {
       
    }
    else
    {
        cout<<i<<" ";
    }
   }

}

int main()
{
    int a=12;
    int b=23;

     func(a,b);

}