#include<iostream>
using namespace std;
int main()
{
    int arr1[9]={12,13,14,15,16,17,18,19,20};
    int arr2[9]={1,2,3,4,5,6,7,8,9};
    int arr3[9]={101,104,107,102,105,108,103,106,109};
    int sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8,sum9;

  
    for(int i=0;i<9;i++)
    {
       
            if(i==0)
            {
                sum1=arr1[i]+arr2[i]+arr3[i]; 
            }
           else if(i==1)
           {
                sum2=arr1[i]+arr2[i]+arr3[i];
           }
               if(i==2)
            {
                sum3=arr1[i]+arr2[i]+arr3[i]; 
            }
           else if(i==3)
           {
                sum4=arr1[i]+arr2[i]+arr3[i];
           }


           if(i==4)
            {
                sum5=arr1[i]+arr2[i]+arr3[i]; 
            }
           else if(i==5)
           {
                sum6=arr1[i]+arr2[i]+arr3[i];
           }
               if(i==6)
            {
                sum7=arr1[i]+arr2[i]+arr3[i]; 
            }
           else if(i==7)
           {
                sum8=arr1[i]+arr2[i]+arr3[i];
           }

            else if(i==8)
           {
                sum9=arr1[i]+arr2[i]+arr3[i];
           }  
    }

        


    cout<<sum1<<" "<<sum2<<" "<<sum3<<"\n";
    cout<<sum4<<" "<<sum5<<" "<<sum6<<"\n";
    cout<<sum7<<" "<<sum8<<" "<<sum9<<"\n";
}